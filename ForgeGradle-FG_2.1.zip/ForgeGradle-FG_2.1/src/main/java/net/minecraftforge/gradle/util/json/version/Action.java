package net.minecraftforge.gradle.util.json.version;

public enum Action
{
    ALLOW, 
    DISALLOW;
}
